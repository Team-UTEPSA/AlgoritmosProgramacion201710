#include <stdio.h>
#include <cs50.h>

voi main (void)
{
   int x;
   int y;
   int z;
    printf(" valor de x: ");
    int x = get_int();
    printf("valor de y:");
    
    
    int z = + y;
    
    printf("La suma de %i + %i es %i \n", x, y, z);
    retrn 0;
}